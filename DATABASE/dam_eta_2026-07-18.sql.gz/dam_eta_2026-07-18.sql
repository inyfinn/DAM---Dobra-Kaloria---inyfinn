--
-- PostgreSQL database dump
--

\restrict URxx0io2gZ3xfTvCM6H85yohFyMMlBCOe93f6pAsrLNk9fZzveFDLsENEBDwbO8

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    ts text NOT NULL,
    action text NOT NULL,
    username text DEFAULT 'anonymous'::text NOT NULL,
    path text DEFAULT ''::text NOT NULL,
    local_path text DEFAULT ''::text NOT NULL,
    detail text DEFAULT ''::text NOT NULL,
    meta_json text DEFAULT '{}'::text NOT NULL
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: dam_kv_store; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dam_kv_store (
    store_key text NOT NULL,
    payload jsonb NOT NULL,
    updated_at text NOT NULL,
    updated_by text DEFAULT ''::text NOT NULL
);


--
-- Name: device_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_sessions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    device_id text NOT NULL,
    machine_id text DEFAULT ''::text NOT NULL,
    session_id text DEFAULT ''::text NOT NULL,
    windows_user text DEFAULT ''::text NOT NULL,
    hostname text DEFAULT ''::text NOT NULL,
    token_hash text NOT NULL,
    created_at text NOT NULL,
    last_seen_at text NOT NULL,
    revoked boolean DEFAULT false NOT NULL
);


--
-- Name: device_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.device_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: device_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.device_sessions_id_seq OWNED BY public.device_sessions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    role text DEFAULT 'user'::text NOT NULL,
    password_hash text NOT NULL,
    auth_provider text DEFAULT 'local'::text NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: device_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_sessions ALTER COLUMN id SET DEFAULT nextval('public.device_sessions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, ts, action, username, path, local_path, detail, meta_json) FROM stdin;
1	2026-07-18T09:01:48.532Z	open_folder_explorer	Krzysztof Wieczorek	X:/Marketing/- EKSPORT/01 - PRODUCTS/- GC/01 - BARS/SALTY NUT — [ bars_date ]/BAR - 05.07.2023 - 6300375.00 - GB DE/4 - VISUALS/GC_auto_6300375_GB_DE_RGB.png	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\01 - BARS\\SALTY NUT — [ bars_date ]\\BAR - 05.07.2023 - 6300375.00 - GB DE\\4 - VISUALS	Eksplorator produktu - otworz folder	{}
2	2026-07-18T09:02:57.671Z	open_folder_explorer	Krzysztof Wieczorek	X:/Marketing/- EKSPORT/01 - PRODUCTS/- GC/01 - BARS/LEMON BUNDT CAKE — [ cashews ]/MINI - 18.07.2025 - 6300670.00 - GB CZ SK HU HR/4 - VISUALS/MINI-LEMON-BUNDT-CAKE-6300670-FRONT-S.png	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\01 - BARS\\LEMON BUNDT CAKE — [ cashews ]\\MINI - 18.07.2025 - 6300670.00 - GB CZ SK HU HR\\4 - VISUALS	Eksplorator produktu - otworz folder	{}
3	2026-07-18T09:13:28.148Z	open_folder_explorer	Krzysztof Wieczorek	X:/Marketing/- EKSPORT/01 - PRODUCTS/- GC/02 - BALLS/DATE ORANGE — [ balls_raw ]/17.02.2025 - 6300624.00 - SK HU HR/4 - VISUALS/WARIANT-DATE-ORANGE-6300624-FRONT-S.png	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\02 - BALLS\\DATE ORANGE — [ balls_raw ]\\17.02.2025 - 6300624.00 - SK HU HR\\4 - VISUALS	Eksplorator produktu - otworz folder	{}
4	2026-07-18T10:14:41.858Z	open_folder_explorer	Krzysztof Wieczorek	X:/Marketing/- EKSPORT/01 - PRODUCTS/- GC/02 - BALLS/DATE CHERRY — [ balls_raw ]/20.09.2024 - 6300488.00 - GB AR/4 - VISUALS/WARIANT-DATE-CHERRY-6300488.00-FRONT-S.png	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\02 - BALLS\\DATE CHERRY — [ balls_raw ]\\20.09.2024 - 6300488.00 - GB AR\\4 - VISUALS	Eksplorator produktu - otworz folder	{}
5	2026-07-18T10:21:14.281Z	open_folder_explorer	Krzysztof Wieczorek	X:/Marketing/- EKSPORT/01 - PRODUCTS/- GC/02 - BALLS/CORNFLAKES PEANUTS HONEY — [ balls_crispy ]/2025 10 30 GB DE-6300699.01 - 80 G - 05.07.2024 - 6300699.00/4 - VISUALS/2025-10-30-GB-DE-630-CORNFLAKES-PEANUTS-HONEY-6300699-FRONT-S.png	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\02 - BALLS\\CORNFLAKES PEANUTS HONEY — [ balls_crispy ]\\2025 10 30 GB DE-6300699.01 - 80 G - 05.07.2024 - 6300699.00\\4 - VISUALS	Eksplorator produktu - otworz folder	{}
6	2026-07-18T10:24:26.257Z	open_folder_explorer	Krzysztof Wieczorek	X:/Marketing/- EKSPORT/01 - PRODUCTS/- GC/02 - BALLS/CORNFLAKES PEANUTS HONEY — [ balls_crispy ]/2025 10 30 GB DE-6300699.01 - 80 G - 05.07.2024 - 6300699.00/4 - VISUALS/2025-10-30-GB-DE-630-CORNFLAKES-PEANUTS-HONEY-6300699-FRONT-S.png	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\02 - BALLS\\CORNFLAKES PEANUTS HONEY — [ balls_crispy ]\\2025 10 30 GB DE-6300699.01 - 80 G - 05.07.2024 - 6300699.00\\4 - VISUALS	Eksplorator produktu - otworz folder	{}
7	2026-07-18T13:31:21.546351+00:00	viz_request_email_stub	qa-test@local			TO: krzysztof.wieczorek@kubara.pl, szymon.ryngwelski@kubara.pl, sylwia.zarychta@kubara.pl | Prosze o wykonanie wizualizacji na TEST PRODUKT (Polska) - indeks 0000000. Zglosil: qa-test@local.	{}
8	2026-07-18T13:31:21.551131+00:00	viz_request_asana_stub	qa-test@local			Prosze o wykonanie wizualizacji na TEST PRODUKT (Polska) - indeks 0000000. Zglosil: qa-test@local.\nFolder: X:/test/path\nMarka: DK\nKategoria: TEST\nTyp: DOYPACK	{}
9	2026-07-18T13:31:21.556499+00:00	viz_request_created	qa-test@local	X:/test/path		Prosze o wykonanie wizualizacji na TEST PRODUKT (Polska) - indeks 0000000. Zglosil: qa-test@local.	{}
10	2026-07-18T13:59:54.694Z	open_folder_explorer	Krzysztof Wieczorek	X:/Marketing/- EKSPORT/01 - PRODUCTS/- GC/02 - BALLS/OATS CHOCOLATE — [ balls_crispy ]/FOL - 27.01.2023 - 0000000.00 - GB AR FR NL (2)/4 - VISUALS/WARIANT-OATS-CHOCOLATE-6300272-FRONT-S.png	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\02 - BALLS\\OATS CHOCOLATE — [ balls_crispy ]\\FOL - 27.01.2023 - 0000000.00 - GB AR FR NL (2)\\4 - VISUALS	Eksplorator produktu - otworz folder	{}
11	2026-07-18T14:01:02.546Z	open_folder_explorer	Krzysztof Wieczorek	X:/Marketing/- EKSPORT/01 - PRODUCTS/- GC/02 - BALLS/OATS CHOCOLATE — [ balls_crispy ]/FOL - 04.07.2023 - GB_DE_630369.00/4 - VISUALS/WARIANT-OATS-CHOCOLATE-6300272-FRONT-S.png	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\02 - BALLS\\OATS CHOCOLATE — [ balls_crispy ]\\FOL - 04.07.2023 - GB_DE_630369.00\\4 - VISUALS	Eksplorator produktu - otworz folder	{}
12	2026-07-18T14:11:11.069Z	open_folder_explorer	Krzysztof Wieczorek	X:/Marketing/- EKSPORT/01 - PRODUCTS/- GC/02 - BALLS/DATE LIME — [ balls_raw ]/20.09.2024 - 6300489.00/4 - VISUALS/PROJEKT-DATE-LIME-6300489-FRONT-S.png	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\02 - BALLS\\DATE LIME — [ balls_raw ]\\20.09.2024 - 6300489.00\\4 - VISUALS	Eksplorator produktu - otworz folder	{}
13	2026-07-18T14:13:08.770585+00:00	rename_revision_prefix	krzysztof.wieczorek@kubara.pl	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\02 - BALLS\\CORNFLAKES PEANUTS HONEY — [ balls_crispy ]\\FOLIA - 20.09.2024 - 6300478.00 - GB AR		FOLIA -> FOLIA	{}
14	2026-07-18T14:18:39.204Z	open_folder_explorer	Krzysztof Wieczorek	X:/Marketing/- EKSPORT/01 - PRODUCTS/- GC/02 - BALLS/DATE ORANGE — [ balls_raw ]/17.02.2025 - 6300624.00 - SK HU HR/4 - VISUALS/WARIANT-DATE-ORANGE-6300624-FRONT-S.png	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\02 - BALLS\\DATE ORANGE — [ balls_raw ]\\17.02.2025 - 6300624.00 - SK HU HR\\4 - VISUALS	Eksplorator produktu - otworz folder	{}
15	2026-07-18T15:07:52.355895+00:00	phase4_test	agent			postgres live	{}
16	2026-07-18T15:15:54.840Z	reveal_explorer	Krzysztof Wieczorek	X:/Marketing/- POLSKA/01 - PRODUKTY/- DK/02 - KULKI/CZARNA PORZECZKA — [ owocowe ]/DOY - MAGNEZ & ŻELAZO - 65 g - 24.02.2026 - 6300753.00	X:\\Marketing\\- POLSKA\\01 - PRODUKTY\\- DK\\02 - KULKI\\CZARNA PORZECZKA — [ owocowe ]\\DOY - MAGNEZ & ŻELAZO - 65 g - 24.02.2026 - 6300753.00	Pokaz w Eksploratorze	{}
17	2026-07-18T15:30:17.670Z	reveal_explorer	Krzysztof Wieczorek	X:/Marketing/- POLSKA/01 - PRODUKTY/- DK/02 - KULKI/CZARNA PORZECZKA — [ owocowe ]/DOY - MAGNEZ & ŻELAZO - 65 g - 24.02.2026 - 6300753.00	X:\\Marketing\\- POLSKA\\01 - PRODUKTY\\- DK\\02 - KULKI\\CZARNA PORZECZKA — [ owocowe ]\\DOY - MAGNEZ & ŻELAZO - 65 g - 24.02.2026 - 6300753.00	Pokaz w Eksploratorze	{}
18	2026-07-18T15:30:22.100Z	reveal_explorer	Krzysztof Wieczorek	X:/Marketing/- POLSKA/01 - PRODUKTY/- DK/02 - KULKI/CZARNA PORZECZKA — [ owocowe ]/DOY - MAGNEZ & ŻELAZO - 65 g - 24.02.2026 - 6300753.00	X:\\Marketing\\- POLSKA\\01 - PRODUKTY\\- DK\\02 - KULKI\\CZARNA PORZECZKA — [ owocowe ]\\DOY - MAGNEZ & ŻELAZO - 65 g - 24.02.2026 - 6300753.00	Pokaz w Eksploratorze	{}
\.


--
-- Data for Name: dam_kv_store; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dam_kv_store (store_key, payload, updated_at, updated_by) FROM stdin;
product-aliases	{"groups": [{"note": "OWIES MIOD (DK, PL) i CORNFLAKES PEANUTS HONEY (GC, eksport) to ten sam produkt - wariant jezykowy. Przykład uzytkownika 2026-07-18.", "members": [{"brand": "DK", "product_id": "owies-miod-sniadanie"}, {"brand": "GC", "product_id": "cornflakes-peanuts-honey-balls-crispy"}], "linked_by": "index", "canonical_id": "owies-miod-sniadanie", "shared_index_base": "6300699"}], "_readme": "Aliasy = TEN SAM produkt pod inna marka/jezykiem (DK<->GC). Powiazanie: 1) po wspolnym indeksie (linked_by=index) 2) recznie przez admina/power_user - wskazanie folderu lub wpisanie indeksow (linked_by=manual). Zapis przez Faze 4 (kolejka moderacji) - patrz tag-proposals.json."}	2026-07-18T15:05:40.619579+00:00	migrate_to_postgres.py
naming-dictionary	{"ui": {"demo_label": "Demo", "mix_prefix": "MIX - ", "no_index_label": "Bez indeksu", "multi_lang_label": "Multijęzyczny", "multi_index_label": "Warianty"}, "sizes": {"L": "krótsza krawędź >= 1300 px", "S": "krótsza krawędź < 1300 px"}, "brands": {"DK": {"path_hint": "- POLSKA/01 - PRODUKTY/- DK", "default_lang": "pl"}, "GC": {"path_hint": "- EKSPORT/01 - PRODUCTS/- GC", "default_lang": "gb"}}, "version": 1, "carriers": {"BAT": {"aliases": ["BAT", "BATON", "BAR"], "label_pl": "BATON"}, "DOY": {"aliases": ["DOY", "DOYPACK", "POUCH"], "label_pl": "DOYPACK"}, "ETY": {"aliases": ["ETY", "ETYKIETA", "LABEL"], "label_pl": "ETYKIETA"}, "KAR": {"aliases": ["KAR", "KARTON", "CARTON"], "label_pl": "KARTON"}, "OBW": {"aliases": ["OBW", "OBWOLUTA"], "label_pl": "OBWOLUTA"}, "MINI": {"aliases": ["MINI", "MINI BATON", "MINI BAR"], "label_pl": "MINI BATON"}, "SASZ": {"aliases": ["SASZ", "SACHET"], "label_pl": "SASZETKA"}, "SHOT": {"aliases": ["SHOT"], "label_pl": "SHOT"}, "TUBA": {"aliases": ["TUBA", "TUBE"], "label_pl": "TUBA"}, "DOY6X": {"aliases": ["DOY6X", "DOY 6X", "DOYPACK 6"], "label_pl": "DOYPACK 6x MINI"}, "FOLIA": {"aliases": ["FOLIA", "FOL", "FOIL"], "label_pl": "FOLIA"}, "KAR6X": {"aliases": ["KAR6X", "KAR 6X", "KARTON 6", "CARTON 6x MINI"], "label_pl": "KARTON 6x MINI"}, "REKAW": {"aliases": ["REKAW", "RĘKAW", "SLEEVE", "OWIJKA"], "label_pl": "RĘKAW"}, "WIZKA": {"aliases": ["WIZKA", "WIZKI"], "label_pl": "WIZUALIZACJE"}, "BIGPAK": {"aliases": ["BIGPAK", "BIGPACK", "BIG PAK"], "label_pl": "BIGPAK"}, "ETY-BUT": {"aliases": ["ETY-BUT", "ETY BUT", "LABEL-GLASS"], "label_pl": "ETYKIETA BUTELKA"}, "ETY-SLO": {"aliases": ["ETY-SLO", "ETY SLO", "LABEL-JAR"], "label_pl": "ETYKIETA SŁOIK"}}, "ai_states": {"": "robocza", "-F": "Finished - layout skonczony", "-FQ": "Finished Quality - zatwierdzony do druku"}, "languages": {"at": "Austria", "be": "Belgia", "bg": "Bułgaria", "ch": "Szwajcaria", "cz": "Czechy", "de": "Niemcy", "dk": "Dania", "ee": "Estonia", "es": "Hiszpania", "fi": "Finlandia", "fr": "Francja", "gb": "Wielka Brytania", "gr": "Grecja", "hr": "Chorwacja", "hu": "Węgry", "ie": "Irlandia", "it": "Włochy", "lt": "Litwa", "lv": "Łotwa", "nl": "Holandia", "no": "Norwegia", "pl": "Polska", "pt": "Portugalia", "ro": "Rumunia", "ru": "Rosja", "se": "Szwecja", "si": "Słowenia", "sk": "Słowacja", "uk": "Ukraina"}, "categories": [{"id": "BATONY", "title": "BATONY", "labels": ["BATONY", "BARS"]}, {"id": "KULKI", "title": "KULKI", "labels": ["KULKI", "BALLS"]}, {"id": "ROSLINNE", "title": "ROŚLINNE", "labels": ["ROSLINNE", "ROŚLINNE", "PLANT BASED", "PLANT-BASED"]}, {"id": "SYPKIE", "title": "SYPKIE", "labels": ["SYPKIE", "BREAKFAST"]}, {"id": "NAPOJE", "title": "NAPOJE", "labels": ["NAPOJE", "DRINKS"]}, {"id": "PRZETWORY", "title": "PRZETWORY", "labels": ["PRZETWORY", "SPREADS", "CREAMS", "KREMY"]}, {"id": "DATESY", "title": "DATESY", "labels": ["DATESY", "DATES"]}], "lang_aliases": {"en": "gb", "ua": "uk"}, "perspectives": {"BACK": ["BACK", "TYL", "TYŁ"], "LEFT": ["LEFT", "LEWO"], "OPEN": ["OPEN", "OTWARTE"], "FRONT": ["FRONT"], "RIGHT": ["RIGHT", "PRAWO"], "CLOSED": ["CLOSED", "ZAMKNIETE", "ZAMKNIĘTE"], "MOCKUP": ["MOCKUP"]}, "carrier_detect_order": ["KAR6X", "DOY6X", "ETY-BUT", "ETY-SLO", "DOY", "KAR", "MINI", "BAT", "BIGPAK", "TUBA", "FOLIA", "SASZ", "REKAW", "OBW", "ETY", "SHOT", "WIZKA"]}	2026-07-18T15:05:40.810122+00:00	migrate_to_postgres.py
carrier-types	{"custom_types": {}, "deleted_types": {}}	2026-07-18T15:05:41.167899+00:00	migrate_to_postgres.py
carrier-assignment-log	{"entries": [{"ts": "2026-07-18T14:13:08.775007+00:00", "actor": "krzysztof.wieczorek@kubara.pl", "carrier_code": "FOLIA", "revision_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\CORNFLAKES PEANUTS HONEY — [ balls_crispy ]\\\\FOLIA - 20.09.2024 - 6300478.00 - GB AR"}]}	2026-07-18T15:05:41.334992+00:00	migrate_to_postgres.py
notification-groups	{"grafik": [{"name": "Krzysztof Wieczorek", "email": "krzysztof.wieczorek@kubara.pl"}, {"name": "Szymon Ryngwelski", "email": "szymon.ryngwelski@kubara.pl"}, {"name": "Sylwia Zarychta", "email": "sylwia.zarychta@kubara.pl"}], "_readme": "Grupy odbiorcow powiadomien. Edytuj ta liste, aby dodac/usunac osobe - kod NIE trzeba zmieniac (2026-07-18)."}	2026-07-18T15:05:41.409537+00:00	migrate_to_postgres.py
carrier-overrides	{"note": "Reczne / skorygowane mapowanie nosnika gdy folder nie ma prefiksu (np. tylko data-indeks). NIGDY nie zgaduj BATON.", "overrides": {"6300622.00": {"note": "Babka cytrynowa - stary karton 6x", "status": "nieaktualne", "carrier": "KAR6X"}, "D:/Marketing/- POLSKA/01 - PRODUKTY/- DK/01 - BATONY/BABKA CYTRYNOWA — [ nerkowcowy ]/13.02.2025 - 6300622.00": {"note": "Starsza wersja KARTON 6x MINI BATONIKI (2025) - nie BATON", "market": "DK", "status": "nieaktualne", "carrier": "KAR6X"}}, "updated_at": "2026-07-17T18:00:00"}	2026-07-18T15:05:41.628054+00:00	migrate_to_postgres.py
viz-flags	{"demo": {"test|6300707|pl": true, "proteina-banoffee-krem-orzechowy|6300707|pl": true}, "hidden": {}, "manual": [], "updated_at": "2026-07-18T13:53:41.819547+00:00"}	2026-07-18T15:05:41.784698+00:00	migrate_to_postgres.py
thumb-overrides	{"salty-nut-bars-date": {"file": "GC_bar_salty_nut_6300482_GB_RGB.png", "path": "X:/Marketing/- EKSPORT/01 - PRODUCTS/- GC/01 - BARS/SALTY NUT — [ bars_date ]/BAR - 20.09.2024 - GB_AR_6300482.00 - GB AR/4 - VISUALS/GC_bar_salty_nut_6300482_GB_RGB.png", "thumb_url": "data/thumbs/salty-nut-bars-date__6300482_gb.jpg?v=1681873798", "updated_at": "2026-07-18T09:03:41.392682+00:00"}}	2026-07-18T15:05:41.844618+00:00	migrate_to_postgres.py
tag-proposals	{"proposals": []}	2026-07-18T15:05:52.853953+00:00	phase4-test
inbox-items	{"items": []}	2026-07-18T15:06:00.957647+00:00	local_bridge
\.


--
-- Data for Name: device_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.device_sessions (id, user_id, device_id, machine_id, session_id, windows_user, hostname, token_hash, created_at, last_seen_at, revoked) FROM stdin;
1	1	dam-dev-a6a2acce751029d4e04eb1e410740948	dam-mid-a6a2acce751029d4e04eb1e410740948	dam-sid-exvvR1f1rZyk97awIRTfKOCNeN3_7Jvr	xpret	inyfinn	bf70a802d79de2a4f3de7f0177d27ca8defa1224d3e0f4073ed77970fe22ab7b	2026-07-18T08:23:51.685049+00:00	2026-07-18T13:09:49.413101+00:00	f
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, name, role, password_hash, auth_provider, created_at, updated_at) FROM stdin;
1	krzysztof.wieczorek@kubara.pl	Krzysztof Wieczorek	admin	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:52:34.147789+00:00	2026-07-18T00:53:15.512123+00:00
2	agata.karon@kubara.pl	Agata Karon	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
3	andzelika.borowicz@kubara.pl	Andzelika Borowicz	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
4	anna.polanska@kubara.pl	Anna Polanska	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
5	beata.scibik@kubara.pl	Beata Scibik	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
6	dagmara.bartnik@kubara.pl	Dagmara Bartnik	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
7	ewa.prazmowska@kubara.pl	Ewa Prazmowska	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
8	justyna.zroslak@kubara.pl	Justyna Zroslak	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
9	karolina.kubara@kubara.pl	Karolina Kubara	power_user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
10	maciej.labus@kubara.pl	Maciej Labus	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
11	magazyn.detal@kubara.pl	Magazyn Detal	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
12	malgorzata.oleksiak@kubara.pl	Malgorzata Oleksiak	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
13	marek.milek@kubara.pl	Marek Milek	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
14	marek.paluszewski@kubara.pl	Marek Paluszewski	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
15	marta.zasepa@kubara.pl	Marta Zasepa	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
16	ryszard.domagala@kubara.pl	Ryszard Domagala	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
17	sylwia.zarychta@kubara.pl	Sylwia Zarychta	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
18	szymon.ryngwelski@kubara.pl	Szymon Ryngwelski	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 18, true);


--
-- Name: device_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.device_sessions_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 18, true);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: dam_kv_store dam_kv_store_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dam_kv_store
    ADD CONSTRAINT dam_kv_store_pkey PRIMARY KEY (store_key);


--
-- Name: device_sessions device_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_sessions
    ADD CONSTRAINT device_sessions_pkey PRIMARY KEY (id);


--
-- Name: device_sessions device_sessions_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_sessions
    ADD CONSTRAINT device_sessions_token_hash_key UNIQUE (token_hash);


--
-- Name: device_sessions device_sessions_user_id_device_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_sessions
    ADD CONSTRAINT device_sessions_user_id_device_id_key UNIQUE (user_id, device_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: audit_log_action_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_action_idx ON public.audit_log USING btree (action);


--
-- Name: audit_log_ts_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_ts_idx ON public.audit_log USING btree (ts DESC);


--
-- Name: audit_log_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_user_idx ON public.audit_log USING btree (username);


--
-- Name: users_email_lower_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_lower_idx ON public.users USING btree (lower(email));


--
-- Name: device_sessions device_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_sessions
    ADD CONSTRAINT device_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict URxx0io2gZ3xfTvCM6H85yohFyMMlBCOe93f6pAsrLNk9fZzveFDLsENEBDwbO8

