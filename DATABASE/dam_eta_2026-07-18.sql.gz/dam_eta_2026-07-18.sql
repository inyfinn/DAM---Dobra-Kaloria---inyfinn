--
-- PostgreSQL database dump
--

\restrict RnQCYPX6gcXeLjX5rQbChl0uoPZ2xdgdKPZkvbWlJN1a1djwBWyDDm7gFqYfzyg

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    ts text NOT NULL,
    action text NOT NULL,
    username text DEFAULT 'anonymous'::text NOT NULL,
    path text DEFAULT ''::text NOT NULL,
    local_path text DEFAULT ''::text NOT NULL,
    detail text DEFAULT ''::text NOT NULL,
    meta_json text DEFAULT '{}'::text NOT NULL
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: dam_kv_store; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dam_kv_store (
    store_key text NOT NULL,
    payload jsonb NOT NULL,
    updated_at text NOT NULL,
    updated_by text DEFAULT ''::text NOT NULL
);


--
-- Name: device_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_sessions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    device_id text NOT NULL,
    machine_id text DEFAULT ''::text NOT NULL,
    session_id text DEFAULT ''::text NOT NULL,
    windows_user text DEFAULT ''::text NOT NULL,
    hostname text DEFAULT ''::text NOT NULL,
    token_hash text NOT NULL,
    created_at text NOT NULL,
    last_seen_at text NOT NULL,
    revoked boolean DEFAULT false NOT NULL
);


--
-- Name: device_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.device_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: device_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.device_sessions_id_seq OWNED BY public.device_sessions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    role text DEFAULT 'user'::text NOT NULL,
    password_hash text NOT NULL,
    auth_provider text DEFAULT 'local'::text NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: device_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_sessions ALTER COLUMN id SET DEFAULT nextval('public.device_sessions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, ts, action, username, path, local_path, detail, meta_json) FROM stdin;
1	2026-07-18T09:01:48.532Z	open_folder_explorer	Krzysztof Wieczorek	X:/Marketing/- EKSPORT/01 - PRODUCTS/- GC/01 - BARS/SALTY NUT — [ bars_date ]/BAR - 05.07.2023 - 6300375.00 - GB DE/4 - VISUALS/GC_auto_6300375_GB_DE_RGB.png	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\01 - BARS\\SALTY NUT — [ bars_date ]\\BAR - 05.07.2023 - 6300375.00 - GB DE\\4 - VISUALS	Eksplorator produktu - otworz folder	{}
2	2026-07-18T09:02:57.671Z	open_folder_explorer	Krzysztof Wieczorek	X:/Marketing/- EKSPORT/01 - PRODUCTS/- GC/01 - BARS/LEMON BUNDT CAKE — [ cashews ]/MINI - 18.07.2025 - 6300670.00 - GB CZ SK HU HR/4 - VISUALS/MINI-LEMON-BUNDT-CAKE-6300670-FRONT-S.png	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\01 - BARS\\LEMON BUNDT CAKE — [ cashews ]\\MINI - 18.07.2025 - 6300670.00 - GB CZ SK HU HR\\4 - VISUALS	Eksplorator produktu - otworz folder	{}
3	2026-07-18T09:13:28.148Z	open_folder_explorer	Krzysztof Wieczorek	X:/Marketing/- EKSPORT/01 - PRODUCTS/- GC/02 - BALLS/DATE ORANGE — [ balls_raw ]/17.02.2025 - 6300624.00 - SK HU HR/4 - VISUALS/WARIANT-DATE-ORANGE-6300624-FRONT-S.png	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\02 - BALLS\\DATE ORANGE — [ balls_raw ]\\17.02.2025 - 6300624.00 - SK HU HR\\4 - VISUALS	Eksplorator produktu - otworz folder	{}
4	2026-07-18T10:14:41.858Z	open_folder_explorer	Krzysztof Wieczorek	X:/Marketing/- EKSPORT/01 - PRODUCTS/- GC/02 - BALLS/DATE CHERRY — [ balls_raw ]/20.09.2024 - 6300488.00 - GB AR/4 - VISUALS/WARIANT-DATE-CHERRY-6300488.00-FRONT-S.png	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\02 - BALLS\\DATE CHERRY — [ balls_raw ]\\20.09.2024 - 6300488.00 - GB AR\\4 - VISUALS	Eksplorator produktu - otworz folder	{}
5	2026-07-18T10:21:14.281Z	open_folder_explorer	Krzysztof Wieczorek	X:/Marketing/- EKSPORT/01 - PRODUCTS/- GC/02 - BALLS/CORNFLAKES PEANUTS HONEY — [ balls_crispy ]/2025 10 30 GB DE-6300699.01 - 80 G - 05.07.2024 - 6300699.00/4 - VISUALS/2025-10-30-GB-DE-630-CORNFLAKES-PEANUTS-HONEY-6300699-FRONT-S.png	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\02 - BALLS\\CORNFLAKES PEANUTS HONEY — [ balls_crispy ]\\2025 10 30 GB DE-6300699.01 - 80 G - 05.07.2024 - 6300699.00\\4 - VISUALS	Eksplorator produktu - otworz folder	{}
6	2026-07-18T10:24:26.257Z	open_folder_explorer	Krzysztof Wieczorek	X:/Marketing/- EKSPORT/01 - PRODUCTS/- GC/02 - BALLS/CORNFLAKES PEANUTS HONEY — [ balls_crispy ]/2025 10 30 GB DE-6300699.01 - 80 G - 05.07.2024 - 6300699.00/4 - VISUALS/2025-10-30-GB-DE-630-CORNFLAKES-PEANUTS-HONEY-6300699-FRONT-S.png	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\02 - BALLS\\CORNFLAKES PEANUTS HONEY — [ balls_crispy ]\\2025 10 30 GB DE-6300699.01 - 80 G - 05.07.2024 - 6300699.00\\4 - VISUALS	Eksplorator produktu - otworz folder	{}
7	2026-07-18T13:31:21.546351+00:00	viz_request_email_stub	qa-test@local			TO: krzysztof.wieczorek@kubara.pl, szymon.ryngwelski@kubara.pl, sylwia.zarychta@kubara.pl | Prosze o wykonanie wizualizacji na TEST PRODUKT (Polska) - indeks 0000000. Zglosil: qa-test@local.	{}
8	2026-07-18T13:31:21.551131+00:00	viz_request_asana_stub	qa-test@local			Prosze o wykonanie wizualizacji na TEST PRODUKT (Polska) - indeks 0000000. Zglosil: qa-test@local.\nFolder: X:/test/path\nMarka: DK\nKategoria: TEST\nTyp: DOYPACK	{}
9	2026-07-18T13:31:21.556499+00:00	viz_request_created	qa-test@local	X:/test/path		Prosze o wykonanie wizualizacji na TEST PRODUKT (Polska) - indeks 0000000. Zglosil: qa-test@local.	{}
10	2026-07-18T13:59:54.694Z	open_folder_explorer	Krzysztof Wieczorek	X:/Marketing/- EKSPORT/01 - PRODUCTS/- GC/02 - BALLS/OATS CHOCOLATE — [ balls_crispy ]/FOL - 27.01.2023 - 0000000.00 - GB AR FR NL (2)/4 - VISUALS/WARIANT-OATS-CHOCOLATE-6300272-FRONT-S.png	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\02 - BALLS\\OATS CHOCOLATE — [ balls_crispy ]\\FOL - 27.01.2023 - 0000000.00 - GB AR FR NL (2)\\4 - VISUALS	Eksplorator produktu - otworz folder	{}
11	2026-07-18T14:01:02.546Z	open_folder_explorer	Krzysztof Wieczorek	X:/Marketing/- EKSPORT/01 - PRODUCTS/- GC/02 - BALLS/OATS CHOCOLATE — [ balls_crispy ]/FOL - 04.07.2023 - GB_DE_630369.00/4 - VISUALS/WARIANT-OATS-CHOCOLATE-6300272-FRONT-S.png	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\02 - BALLS\\OATS CHOCOLATE — [ balls_crispy ]\\FOL - 04.07.2023 - GB_DE_630369.00\\4 - VISUALS	Eksplorator produktu - otworz folder	{}
12	2026-07-18T14:11:11.069Z	open_folder_explorer	Krzysztof Wieczorek	X:/Marketing/- EKSPORT/01 - PRODUCTS/- GC/02 - BALLS/DATE LIME — [ balls_raw ]/20.09.2024 - 6300489.00/4 - VISUALS/PROJEKT-DATE-LIME-6300489-FRONT-S.png	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\02 - BALLS\\DATE LIME — [ balls_raw ]\\20.09.2024 - 6300489.00\\4 - VISUALS	Eksplorator produktu - otworz folder	{}
13	2026-07-18T14:13:08.770585+00:00	rename_revision_prefix	krzysztof.wieczorek@kubara.pl	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\02 - BALLS\\CORNFLAKES PEANUTS HONEY — [ balls_crispy ]\\FOLIA - 20.09.2024 - 6300478.00 - GB AR		FOLIA -> FOLIA	{}
14	2026-07-18T14:18:39.204Z	open_folder_explorer	Krzysztof Wieczorek	X:/Marketing/- EKSPORT/01 - PRODUCTS/- GC/02 - BALLS/DATE ORANGE — [ balls_raw ]/17.02.2025 - 6300624.00 - SK HU HR/4 - VISUALS/WARIANT-DATE-ORANGE-6300624-FRONT-S.png	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\02 - BALLS\\DATE ORANGE — [ balls_raw ]\\17.02.2025 - 6300624.00 - SK HU HR\\4 - VISUALS	Eksplorator produktu - otworz folder	{}
15	2026-07-18T15:07:52.355895+00:00	phase4_test	agent			postgres live	{}
16	2026-07-18T15:15:54.840Z	reveal_explorer	Krzysztof Wieczorek	X:/Marketing/- POLSKA/01 - PRODUKTY/- DK/02 - KULKI/CZARNA PORZECZKA — [ owocowe ]/DOY - MAGNEZ & ŻELAZO - 65 g - 24.02.2026 - 6300753.00	X:\\Marketing\\- POLSKA\\01 - PRODUKTY\\- DK\\02 - KULKI\\CZARNA PORZECZKA — [ owocowe ]\\DOY - MAGNEZ & ŻELAZO - 65 g - 24.02.2026 - 6300753.00	Pokaz w Eksploratorze	{}
17	2026-07-18T15:30:17.670Z	reveal_explorer	Krzysztof Wieczorek	X:/Marketing/- POLSKA/01 - PRODUKTY/- DK/02 - KULKI/CZARNA PORZECZKA — [ owocowe ]/DOY - MAGNEZ & ŻELAZO - 65 g - 24.02.2026 - 6300753.00	X:\\Marketing\\- POLSKA\\01 - PRODUKTY\\- DK\\02 - KULKI\\CZARNA PORZECZKA — [ owocowe ]\\DOY - MAGNEZ & ŻELAZO - 65 g - 24.02.2026 - 6300753.00	Pokaz w Eksploratorze	{}
18	2026-07-18T15:30:22.100Z	reveal_explorer	Krzysztof Wieczorek	X:/Marketing/- POLSKA/01 - PRODUKTY/- DK/02 - KULKI/CZARNA PORZECZKA — [ owocowe ]/DOY - MAGNEZ & ŻELAZO - 65 g - 24.02.2026 - 6300753.00	X:\\Marketing\\- POLSKA\\01 - PRODUKTY\\- DK\\02 - KULKI\\CZARNA PORZECZKA — [ owocowe ]\\DOY - MAGNEZ & ŻELAZO - 65 g - 24.02.2026 - 6300753.00	Pokaz w Eksploratorze	{}
19	2026-07-18T16:50:54.444996+00:00	tag_proposal_submitted	ola@test.pl	X:/Marketing/- POLSKA/- DK/_TEST_PROP_DUMMY		BAG -> DOY (pending)	{}
20	2026-07-18T16:50:54.970433+00:00	tag_proposal_submitted	ola@test.pl	X:/Marketing/- POLSKA/- DK/_TEST_PROP_DUMMY2		BAG -> DOY (pending)	{}
21	2026-07-18T16:56:06.630141+00:00	tag_proposal_rejected	moderator	X:/Marketing/- POLSKA/- DK/_TEST_PROP_DUMMY			{}
22	2026-07-18T18:30:10.450536+00:00	rename_revision_prefix	krzysztof.wieczorek@kubara.pl	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\02 - BALLS\\DATE ORANGE — [ balls_raw ]\\DOYPACK - 17.02.2025 - 6300624.00 - SK HU HR		? -> DOY (+5 plikow)	{}
23	2026-07-18T18:31:00.462718+00:00	rename_revision_prefix	krzysztof.wieczorek@kubara.pl	X:\\Marketing\\- EKSPORT\\01 - PRODUCTS\\- GC\\02 - BALLS\\DATE ORANGE — [ balls_raw ]\\DOYPACK - 20.09.2024 - 6300490.00 - GB AR		DOY -> DOY (+3 plikow)	{}
24	2026-07-18T19:36:49.948405+00:00	index_rebuild	system			ok	{"rc": 0}
25	2026-07-18T19:59:32.458414+00:00	index_rebuild	system			ok	{"rc": 0}
\.


--
-- Data for Name: dam_kv_store; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dam_kv_store (store_key, payload, updated_at, updated_by) FROM stdin;
product-aliases	{"groups": [{"note": "OWIES MIOD (DK, PL) i CORNFLAKES PEANUTS HONEY (GC, eksport) to ten sam produkt - wariant jezykowy. Przykład uzytkownika 2026-07-18.", "members": [{"brand": "DK", "product_id": "owies-miod-sniadanie"}, {"brand": "GC", "product_id": "cornflakes-peanuts-honey-balls-crispy"}], "linked_by": "index", "canonical_id": "owies-miod-sniadanie", "shared_index_base": "6300699"}], "_readme": "Aliasy = TEN SAM produkt pod inna marka/jezykiem (DK<->GC). Powiazanie: 1) po wspolnym indeksie (linked_by=index) 2) recznie przez admina/power_user - wskazanie folderu lub wpisanie indeksow (linked_by=manual). Zapis przez Faze 4 (kolejka moderacji) - patrz tag-proposals.json."}	2026-07-18T15:05:40.619579+00:00	migrate_to_postgres.py
carrier-types	{"custom_types": {}, "deleted_types": {}}	2026-07-18T15:05:41.167899+00:00	migrate_to_postgres.py
notification-groups	{"grafik": [{"name": "Krzysztof Wieczorek", "email": "krzysztof.wieczorek@kubara.pl"}, {"name": "Szymon Ryngwelski", "email": "szymon.ryngwelski@kubara.pl"}, {"name": "Sylwia Zarychta", "email": "sylwia.zarychta@kubara.pl"}], "_readme": "Grupy odbiorcow powiadomien. Edytuj ta liste, aby dodac/usunac osobe - kod NIE trzeba zmieniac (2026-07-18)."}	2026-07-18T15:05:41.409537+00:00	migrate_to_postgres.py
carrier-overrides	{"note": "Reczne / skorygowane mapowanie nosnika gdy folder nie ma prefiksu (np. tylko data-indeks). NIGDY nie zgaduj BATON.", "overrides": {"6300622.00": {"note": "Babka cytrynowa - stary karton 6x", "status": "nieaktualne", "carrier": "KAR6X"}, "D:/Marketing/- POLSKA/01 - PRODUKTY/- DK/01 - BATONY/BABKA CYTRYNOWA — [ nerkowcowy ]/13.02.2025 - 6300622.00": {"note": "Starsza wersja KARTON 6x MINI BATONIKI (2025) - nie BATON", "market": "DK", "status": "nieaktualne", "carrier": "KAR6X"}}, "updated_at": "2026-07-17T18:00:00"}	2026-07-18T15:05:41.628054+00:00	migrate_to_postgres.py
viz-flags	{"demo": {"test|6300707|pl": true, "proteina-banoffee-krem-orzechowy|6300707|pl": true}, "hidden": {}, "manual": [], "updated_at": "2026-07-18T13:53:41.819547+00:00"}	2026-07-18T15:05:41.784698+00:00	migrate_to_postgres.py
thumb-overrides	{"salty-nut-bars-date": {"file": "GC_bar_salty_nut_6300482_GB_RGB.png", "path": "X:/Marketing/- EKSPORT/01 - PRODUCTS/- GC/01 - BARS/SALTY NUT — [ bars_date ]/BAR - 20.09.2024 - GB_AR_6300482.00 - GB AR/4 - VISUALS/GC_bar_salty_nut_6300482_GB_RGB.png", "thumb_url": "data/thumbs/salty-nut-bars-date__6300482_gb.jpg?v=1681873798", "updated_at": "2026-07-18T09:03:41.392682+00:00"}}	2026-07-18T15:05:41.844618+00:00	migrate_to_postgres.py
tag-proposals	{"proposals": [{"id": "prop_1784393454325", "field": "carrier", "status": "rejected", "decided_at": "2026-07-18T16:56:06+00:00", "decided_by": "moderator", "expires_at": "2026-07-21T16:50:54+00:00", "product_id": "test-prop-1", "product_name": "test propose", "submitted_at": "2026-07-18T16:50:54+00:00", "submitted_by": "ola@test.pl", "current_value": "BAG", "revision_path": "X:/Marketing/- POLSKA/- DK/_TEST_PROP_DUMMY", "proposed_value": "DOY"}, {"id": "prop_1784393454775", "field": "carrier", "status": "pending", "decided_at": null, "decided_by": null, "expires_at": "2026-07-21T16:50:54+00:00", "product_id": "", "product_name": "test2", "submitted_at": "2026-07-18T16:50:54+00:00", "submitted_by": "ola@test.pl", "current_value": "BAG", "revision_path": "X:/Marketing/- POLSKA/- DK/_TEST_PROP_DUMMY2", "proposed_value": "DOY"}]}	2026-07-18T16:56:06.568575+00:00	local_bridge
inbox-items	{"items": [{"id": "inbox_1784393455108", "path": "X:/Marketing/- POLSKA/- DK/_TEST_PROP_DUMMY2", "read": true, "tags": ["moderacja", "tag", "propozycja"], "type": "tag_proposal", "title": "Propozycja typu: BAG -> DOY", "detail": "test2\\nZglosil: ola@test.pl\\nSciezka: X:/Marketing/- POLSKA/- DK/_TEST_PROP_DUMMY2\\nproposal_id: prop_1784393454775", "created_at": "2026-07-18T16:50:55.108644+00:00", "product_id": "", "proposal_id": "prop_1784393454775", "requested_by": "ola@test.pl"}, {"id": "inbox_1784393454704", "path": "X:/Marketing/- POLSKA/- DK/_TEST_PROP_DUMMY", "read": false, "tags": ["moderacja", "tag", "propozycja"], "type": "tag_proposal", "title": "Propozycja typu: BAG -> DOY", "detail": "test propose\\nZglosil: ola@test.pl\\nSciezka: X:/Marketing/- POLSKA/- DK/_TEST_PROP_DUMMY\\nproposal_id: prop_1784393454325", "created_at": "2026-07-18T16:50:54.704612+00:00", "product_id": "test-prop-1", "proposal_id": "prop_1784393454325", "requested_by": "ola@test.pl"}]}	2026-07-18T17:01:08.021138+00:00	local_bridge
carrier-assignment-log	{"entries": [{"ts": "2026-07-18T14:13:08.775007+00:00", "actor": "krzysztof.wieczorek@kubara.pl", "carrier_code": "FOLIA", "revision_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\CORNFLAKES PEANUTS HONEY — [ balls_crispy ]\\\\FOLIA - 20.09.2024 - 6300478.00 - GB AR"}, {"ts": "2026-07-18T18:30:10.755933+00:00", "actor": "krzysztof.wieczorek@kubara.pl", "carrier_code": "DOY", "revision_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOYPACK - 17.02.2025 - 6300624.00 - SK HU HR"}, {"ts": "2026-07-18T18:31:00.761518+00:00", "actor": "krzysztof.wieczorek@kubara.pl", "carrier_code": "DOY", "revision_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOYPACK - 20.09.2024 - 6300490.00 - GB AR"}]}	2026-07-18T18:31:00.787834+00:00	local_bridge
naming-dictionary	{"ui": {"demo_label": "Demo", "mix_prefix": "MIX - ", "no_index_label": "Bez indeksu", "multi_lang_label": "Multijęzyczny", "multi_index_label": "Warianty"}, "sizes": {"L": "krótsza krawędź >= 1300 px", "S": "krótsza krawędź < 1300 px"}, "brands": {"DK": {"path_hint": "- POLSKA/01 - PRODUKTY/- DK", "default_lang": "pl"}, "GC": {"path_hint": "- EKSPORT/01 - PRODUCTS/- GC", "default_lang": "gb"}}, "policy": {"tag_casing": {"note_pl": "Tagi globalne: kody (DK, DOYPACK, GB) zostaja WERSALIKAMI. Etykiety ludzkie (Kulki, Kulki Surowe, Mini batoniki) jak w zdaniu z duza litera. Nie mieszac stylow.", "code_kinds": ["brand", "lang", "carrier", "index"], "code_style": "uppercase_as_stored", "human_kinds": ["category", "subcategory", "smak", "typ", "status", "flag", "autor"], "human_style": "title_case"}, "updated_at": "2026-07-18", "description_pl": "W programie zawsze pelna nazwa nosnika (DOYPACK, FOLIA, BATON). Na dysku Windows (rename folderu/pliku) zawsze skrot (DOY, FOL, BAT). Skroty istnieja tylko po to, zeby nazwy w Eksploratorze zajmowaly mniej miejsca.", "carrier_display_in_ui": "label_pl", "carrier_prefix_on_disk": "short"}, "version": 3, "carriers": {"BAT": {"short": "BAT", "aliases": ["BAT", "BATON", "BAR"], "label_pl": "BATON"}, "DOY": {"short": "DOY", "aliases": ["DOY", "DOYPACK", "POUCH"], "label_pl": "DOYPACK"}, "ETY": {"short": "ETY", "aliases": ["ETY", "ETYKIETA", "LABEL"], "label_pl": "ETYKIETA"}, "KAR": {"short": "KAR", "aliases": ["KAR", "KARTON", "CARTON"], "label_pl": "KARTON"}, "OBW": {"short": "OBW", "aliases": ["OBW", "OBWOLUTA"], "label_pl": "OBWOLUTA"}, "MINI": {"short": "MINI", "aliases": ["MINI", "MINI BATON", "MINI BAR"], "label_pl": "MINI BATON"}, "SASZ": {"short": "SASZ", "aliases": ["SASZ", "SACHET"], "label_pl": "SASZETKA"}, "SHOT": {"short": "SHOT", "aliases": ["SHOT"], "label_pl": "SHOT"}, "TUBA": {"short": "TUBA", "aliases": ["TUBA", "TUBE"], "label_pl": "TUBA"}, "DOY6X": {"short": "DOY6X", "aliases": ["DOY6X", "DOY 6X", "DOYPACK 6"], "label_pl": "DOYPACK 6x MINI"}, "FOLIA": {"short": "FOL", "aliases": ["FOLIA", "FOL", "FOIL"], "label_pl": "FOLIA"}, "KAR6X": {"short": "KAR6X", "aliases": ["KAR6X", "KAR 6X", "KARTON 6", "CARTON 6x MINI"], "label_pl": "KARTON 6x MINI"}, "REKAW": {"short": "REKAW", "aliases": ["REKAW", "RĘKAW", "SLEEVE", "OWIJKA"], "label_pl": "RĘKAW"}, "WIZKA": {"short": "WIZKA", "aliases": ["WIZKA", "WIZKI"], "label_pl": "WIZUALIZACJE"}, "BIGPAK": {"short": "BIGPAK", "aliases": ["BIGPAK", "BIGPACK", "BIG PAK"], "label_pl": "BIGPAK"}, "ETY-BUT": {"short": "ETY-BUT", "aliases": ["ETY-BUT", "ETY BUT", "LABEL-GLASS"], "label_pl": "ETYKIETA BUTELKA"}, "ETY-SLO": {"short": "ETY-SLO", "aliases": ["ETY-SLO", "ETY SLO", "LABEL-JAR"], "label_pl": "ETYKIETA SŁOIK"}}, "ai_states": {"": "robocza", "-F": "Finished - layout skonczony", "-FQ": "Finished Quality - zatwierdzony do druku"}, "languages": {"at": "Austria", "be": "Belgia", "bg": "Bułgaria", "ch": "Szwajcaria", "cz": "Czechy", "de": "Niemcy", "dk": "Dania", "ee": "Estonia", "es": "Hiszpania", "fi": "Finlandia", "fr": "Francja", "gb": "Wielka Brytania", "gr": "Grecja", "hr": "Chorwacja", "hu": "Węgry", "ie": "Irlandia", "it": "Włochy", "lt": "Litwa", "lv": "Łotwa", "nl": "Holandia", "no": "Norwegia", "pl": "Polska", "pt": "Portugalia", "ro": "Rumunia", "ru": "Rosja", "se": "Szwecja", "si": "Słowenia", "sk": "Słowacja", "uk": "Ukraina"}, "categories": [{"id": "BATONY", "title": "Batony", "labels": ["BATONY", "BARS"]}, {"id": "KULKI", "title": "Kulki", "labels": ["KULKI", "BALLS"]}, {"id": "ROSLINNE", "title": "Roślinne", "labels": ["ROSLINNE", "ROŚLINNE", "PLANT BASED", "PLANT-BASED"]}, {"id": "SYPKIE", "title": "Sypkie", "labels": ["SYPKIE", "BREAKFAST"]}, {"id": "NAPOJE", "title": "Napoje", "labels": ["NAPOJE", "DRINKS"]}, {"id": "PRZETWORY", "title": "Przetwory", "labels": ["PRZETWORY", "SPREADS", "CREAMS", "KREMY"]}, {"id": "DATESY", "title": "Datesy", "labels": ["DATESY", "DATES"]}], "lang_aliases": {"en": "gb", "ua": "uk"}, "perspectives": {"BACK": ["BACK", "TYL", "TYŁ"], "LEFT": ["LEFT", "LEWO"], "OPEN": ["OPEN", "OTWARTE"], "FRONT": ["FRONT"], "RIGHT": ["RIGHT", "PRAWO"], "CLOSED": ["CLOSED", "ZAMKNIETE", "ZAMKNIĘTE"], "MOCKUP": ["MOCKUP"]}, "carrier_detect_order": ["KAR6X", "DOY6X", "ETY-BUT", "ETY-SLO", "DOY", "KAR", "MINI", "BAT", "BIGPAK", "TUBA", "FOLIA", "SASZ", "REKAW", "OBW", "ETY", "SHOT", "WIZKA"]}	2026-07-18T19:39:47.404417+00:00	local_bridge
program-instructions	{"version": 4, "title_pl": "Instrukcje programu DAM ETA", "updated_at": "2026-07-18T21:40:00+02:00", "instructions": [{"id": "data.lang_provenance_only", "must": ["Kod jezyka tylko z: (1) lang-overrides.json, (2) token w nazwie folderu rewizji, (3) token w nazwie pliku w rewizji", "Brak sygnalu = puste langs / UI '?'", "Zapisywac lang_source: override|folder|file|unknown", "Stosowac agents/shared/lang-provenance.md przy kazdej zmianie wykrywania jezykow"], "body_pl": "Twarda zasada to POCHODZENIE sygnalu jezyka dla wszystkich kodow (pl/de/gb/cz/sk/...), nie hardcode konkretnego indeksu. Agent musi umiec wskazac fragment nazwy folderu lub pliku (albo override), z ktorego wynika kod. Domysl z marki (GC=gb, DK=pl) albo ze sciezki EKSPORT/POLSKA jest zakazany. Rebuild nie nadpisuje lang-overrides.json. Przyklad metody (nie regula produktu): 6300572 ma CZ+SK bo w PROJECT jest ...CZ_SK...ai.", "category": "data", "must_not": ["Domyslac jezyka z marki, rynku, screenshota opakowania", "Traktowac 'indeks X = jezyk Y' jako regula biznesowa zamiast dowodu z nazwy", "Nadpisywac reczne override przy rebuildzie indeksu"], "priority": "critical", "title_pl": "Jezyk tylko z dowodu (folder/plik/override) - zero zgadywania", "related_kv": ["lang-overrides", "program-instructions"], "updated_at": "2026-07-18", "related_code": ["agents/shared/lang-provenance.md", "apps/web/scripts/build-file-index.py", "apps/web/data/lang-overrides.json", "apps/web/assets/js/dam-viz.js", "apps/web/assets/js/dam-labels.js"]}, {"id": "meta.source_of_truth", "must": ["Przed zmianą reguły biznesowej: przeczytaj program-instructions z KV/cache", "Po decyzji użytkownika: natychmiast dopisz/zaktualizuj instrukcję i wypchnij do Postgres", "Nie odwracaj reguły bez jawnej nowej instrukcji z datą"], "body_pl": "Wszystkie newralgiczne reguły (nazewnictwo, status F/X/D, aktywny/nieaktywny, zakazy UI, zachowanie admina) muszą być zapisane w dam_kv_store jako program-instructions. Agent nie może 'pamiętać inaczej' między sesjami - przed zmianą zachowania czyta ten magazyn. memory.md / process.md tylko odzwierciedlają i logują.", "category": "meta", "must_not": ["Traktować memory.md jako jedyne źródło prawdy", "Zmieniać zachowanie 'bo tak wyglądało w poprzedniej sesji' bez wpisu w program-instructions"], "priority": "critical", "title_pl": "Instrukcje żyją w bazie, nie tylko w memory", "updated_at": "2026-07-18"}, {"id": "naming.carrier_ui_vs_disk", "must": ["UI (badge, meta karty, picker, pasek historii): label_pl (DOYPACK, FOLIA, BATON)", "Rename folderu/pliku na dysku: short (DOY, FOL, BAT) przez CARRIER_FOLDER_PREFIX ze słownika", "Źródło mapowania: naming-dictionary.policy + carriers[].label_pl/short (+ app-settings.naming)"], "body_pl": "DOY, FOL, BAT to tylko skróty w Eksploratorze Windows, żeby nazwy zajmowały mniej miejsca. W programie zawsze rozwinięte: DOYPACK, FOLIA, BATON. Skrót stosujesz wyłącznie przy zmianie nazwy / aktualizacji folderu na dysku.", "category": "naming", "must_not": ["Pokazywać DOY/FOL/BAT jako główną etykietę UI", "Zapisywać na dysku prefiksu DOYPACK/BATON/FOLIA przy nowym rename (stare foldery wolno wykrywać i skracać)"], "priority": "critical", "title_pl": "Nośnik: w programie pełna nazwa, na dysku skrót", "related_kv": ["naming-dictionary", "app-settings"], "updated_at": "2026-07-18", "related_code": ["apps/web/assets/js/dam-labels.js", "apps/desktop/local_bridge.py", "apps/web/settings.html#damNamingPolicy"]}, {"id": "naming.multi_means_multilang", "must": ["Używać ui.multi_lang_label z naming-dictionary (domyślnie Multijęzyczny)"], "body_pl": "Tag Multi na kartach oznacza wariant wielojęzyczny (multi_lang_label), nie 'multi-pack' ani inny typ nośnika.", "category": "naming", "must_not": ["Mylenie Multi z typem opakowania / nośnikiem"], "priority": "high", "title_pl": "Multi = Multijęzyczny", "related_kv": ["naming-dictionary"], "updated_at": "2026-07-18"}, {"id": "ops.change_log_is_truth", "must": ["Przy cofaniu/naprawie: apps/web/data/change-log.json (+ carrier-assignment-log, lifecycle-status)", "Po operacji admina: upewnij się że wpis w logu istnieje"], "body_pl": "Każda istotna operacja (rename nośnika, indeks, lifecycle) trafia do change-log i powiązanych logów. Przy naprawie błędnych rename najpierw czytaj change-log.json / carrier-assignment-log, nie przeszukuj dysku na ślepo.", "category": "operations", "must_not": ["Zgadywanie ścieżek folderów bez wpisu w logu gdy log jest dostępny"], "priority": "critical", "title_pl": "Operacje programu są w logu - nie szukaj na ślepo", "related_kv": ["carrier-assignment-log"], "updated_at": "2026-07-18", "related_files": ["apps/web/data/change-log.json", "apps/web/data/lifecycle-status.json"]}, {"id": "lifecycle.status_fxd", "must": ["F = aktualne / skończony; X = nieaktualne / archiwum; D = demo / prototyp", "Dysk: dopinać ' - F' / ' - X' / ' - D' do nazwy folderu (lifecycle_status.py)", "Produkt X: cascade na warianty + przeniesienie do archiwum kategorii", "Wariant X: archiwum z wrapperem produktu", "Produkt D: cascade - D na warianty; odznaczenie wariantu z D przy produkcie D czyści literkę produktu", "API: POST/GET /lifecycle-status (tylko admin)", "UI tag: Aktualne / Nieaktualne (dam-badge-tag data-tag-kind=status); Admin Shift/dbl"], "body_pl": "Admin oznacza stan literką w nazwie folderu na dysku. F = aktualne, X = nieaktualne (archiwum), D = demo. Odznacz = usuń literkę. Historia previous_name + previous_path w lifecycle-status + change-log.", "category": "lifecycle", "must_not": ["Zmieniać status realnych produktów bez potwierdzenia użytkownika gdy trwa TEST GATE", "Gubić previous_path przy rename statusu (musi dać się cofnąć)"], "notes_pl": "Produkt testowy: TEST LIFECYCLE / indeks TEST-TEST. Litera archiwum na dysku: folder — ARCHIWUM (jak na Marketing).", "priority": "critical", "title_pl": "Status produktu/wariantu: F / X / D", "related_kv": ["lifecycle-status", "product-status", "carrier-overrides"], "updated_at": "2026-07-18", "related_code": ["apps/desktop/lifecycle_status.py", "apps/desktop/local_bridge.py", "apps/web/assets/js/dam-explorer.js"]}, {"id": "lifecycle.product_status_mirror", "must": ["Po sukcesie /lifecycle-status wywołać mirror_lifecycle_to_product_status", "Tag statusu w UI: Aktualne / Nieaktualne (nie surowe F/X w badge jeśli jest ludzka etykieta)"], "body_pl": "Po zmianie lifecycle most zapisuje też mirror do product-status.json (revisions + products), żeby Eksplorer/Wizualizacje widziały Aktualne/Nieaktualne spójnie z dyskiem.", "category": "lifecycle", "priority": "high", "title_pl": "Status w UI + mirror w product-status", "updated_at": "2026-07-18", "related_files": ["apps/web/data/product-status.json", "apps/web/data/lifecycle-status.json"]}, {"id": "ui.em_dash_ban", "must": ["Używać tylko '-'"], "body_pl": "W UI, commitach i copy agentów zakaz znaków — i –. Tylko zwykły myślnik -.", "category": "ui", "must_not": ["Wstawiać U+2014 lub U+2013 w tekstach programu / commitach"], "priority": "critical", "title_pl": "Zakaz em-dash w copy", "updated_at": "2026-07-16"}, {"id": "ui.verify_screenshot", "must": ["Screenshot expanded + collapsed sidebar gdy dotyczy logo", "Sprawdzić konkretnie to, o co prosił user"], "body_pl": "Po każdej zmianie CSS/HTML/JS wpływającej na wygląd: odśwież z cache bust, zrób screenshot narzędziem przeglądarki, przeczytaj plik obrazu (vision). Bez tego nie oddawać.", "category": "ui", "must_not": ["Oddać 'powinno działać' bez screenshot→Read"], "priority": "critical", "title_pl": "Weryfikacja UI = screenshot + Read", "updated_at": "2026-07-18", "related_files": [".cursor/rules/verify-ui-after-changes.mdc"]}, {"id": "ui.geex_only", "must": ["Tokeny dam-tokens.css / dam-brand.css"], "body_pl": "Motyw wyłącznie Geex (#AB54DB). Nie budować Next.js skina ani obcego design systemu w panelu DAM.", "category": "ui", "must_not": ["Wprowadzać Tailwind/shadcn jako deliverable panelu DAM"], "priority": "critical", "title_pl": "UI tylko Geex", "updated_at": "2026-07-16"}, {"id": "admin.header_switch_only", "must": ["localStorage.dam_admin_mode + event dam:admin-mode", "Widoczny tylko dla role=admin"], "body_pl": "Jedyny przełącznik Admin: w headerze tuż po lewej od avatara. Zakaz lokalnych toggle na explorer/viz.", "category": "admin", "must_not": ["#damAdminToggle / #vizAdminToggle / label.dam-admin-toggle"], "priority": "high", "title_pl": "Tryb admina tylko switch w headerze", "updated_at": "2026-07-18"}, {"id": "auth.roles_and_privilege", "must": ["Sprawdzać Authorization: Bearer na bridge"], "body_pl": "Role: admin | power_user | user. Decyzje mutate (rename, lifecycle, carrier-types, overrides, undo/redo, index rebuild) tylko admin z Bearer. Body.role / admin_mode NIE dają privilege.", "category": "auth", "must_not": ["Ufanie spoofowanemu role w JSON body"], "priority": "critical", "title_pl": "Role i privilege na bridge", "updated_at": "2026-07-18"}, {"id": "storage.marketing_sensitive", "must": ["Walidacja folderów -- ARCHIWUM --, - EKSPORT, - POLSKA", "Backup / previous_path przy destrukcyjnych rename"], "body_pl": "Ścieżka bazowa to ustawienie użytkownika (np. X:\\\\Marketing). Operacje rename/move tylko przez most z logiem. Nie kasować hurtowo, nie zgadywać liter dysku.", "category": "storage", "must_not": ["Destrukcja bez logu i bez możliwości cofnięcia gdy da się zachować historię"], "priority": "critical", "title_pl": "Dysk Marketing jest wrażliwy", "updated_at": "2026-07-18"}, {"id": "carrier.do_not_guess", "must": ["Zgłaszać do potwierdzenia zamiast zgadywać"], "body_pl": "Rozpoznanie: 1) overrides, 2) prefiks pliku wizki, 3) prefiks folderu. Gdy brak tokenu - puste / do potwierdzenia, nie zgadywać FOLIA/DOY.", "category": "naming", "must_not": ["Ustawiać nośnik na podstawie samej daty w nazwie folderu"], "priority": "critical", "title_pl": "Nośnika nie zgaduj", "updated_at": "2026-07-18"}, {"id": "ui.tag_casing_global", "must": ["DamLabels.formatTagLabel(label, kind) przy kazdym renderze badge/pill", "category/subcategory/smak/typ = Title Case; carrier/brand/lang/index = jak w slowniku (wersaliki)", "opakowanie w filtrze mapuj do label_pl nosnika (doypack -> DOYPACK)"], "body_pl": "Tagi sa globalne (karty, filtr, explorer, inbox). Kody (DK, GC, DOYPACK, FOLIA, GB, indeks) zostaja WERSALIKAMI jak w slowniku. Etykiety ludzkie (Kulki, Kulki Surowe, Mini batoniki, Warianty) piszemy jak w zdaniu z duza litera. Nie mieszac stylow na jednej karcie (nie KULKI obok Kulki Surowe). Formatter: DamLabels.formatTagLabel.", "category": "ui", "must_not": ["CSS text-transform:uppercase na etykietach ludzkich tagow", "Rozne casingi tej samej kategorii w roznych widokach"], "priority": "critical", "title_pl": "Tagi globalne: wersaliki albo jak w zdaniu - bez mieszania", "related_kv": ["naming-dictionary", "program-instructions"], "updated_at": "2026-07-18", "related_code": ["apps/web/assets/js/dam-labels.js", "apps/web/assets/js/dam-badges.js", "apps/web/assets/js/dam-tag-bar.js"]}, {"id": "ui.product_name_pl_under_en", "must": ["DamLabels.productNamePlParen + .dam-viz-card__title-pl", "Slownik w dam_kv_store.product-name-pl", "Format: ( Nazwa ) ze spacjami w nawiasie"], "body_pl": "Gdy produkt ma angielska nazwe (marka GC), pod tytulem zawsze pokazuj polskie tlumaczenie po nowej linii w nawiasie ze spacjami, np. MINCED / ( Mielone ). Rozmiar jak meta karty, kolor jak tytul. Slownik: product-name-pl.json (KV).", "category": "ui", "must_not": ["Ukrywac PL gdy jest w slowniku", "Szary kolor jak meta - ma byc kolor tytulu"], "priority": "high", "title_pl": "Angielska nazwa GC + polska w nawiasie pod tytulem", "related_kv": ["product-name-pl"], "updated_at": "2026-07-18", "related_code": ["apps/web/assets/js/dam-labels.js", "apps/web/assets/js/dam-viz.js"]}, {"id": "search.product_people", "must": ["Mapa kto↔produkt w product-people.json (+ KV product-people)", "enrich-search-tags.py wlewa autorow do authors / search_blob / by_tag / tag_groups.autor", "Szukajka: sylwia / krzysztof / szymon znajduje przypisane produkty"], "body_pl": "Osoba przy produkcie sluzy do WYSZUKIWANIA (statusy Sylwii, spis Szymona, dziennik KW), nie do glosnych badge TAG na kartach. Zrodlo: apps/web/data/product-people.json. Po aktualizacji mapy: python apps/web/scripts/enrich-search-tags.py (+ seed KV).", "category": "search", "must_not": ["Renderowac imion jako glowne badge na kartach wizualizacji (chyba ze user poprosi)", "Kasowac mape przy rebuildzie file-index bez ponownego enrich"], "priority": "high", "title_pl": "Osoba przy produkcie = wyszukiwanie, nie TAG na karcie", "related_kv": ["product-people", "program-instructions"], "updated_at": "2026-07-18", "related_code": ["apps/web/data/product-people.json", "apps/web/scripts/enrich-search-tags.py", "apps/web/assets/js/dam-search.js"]}], "description_pl": "Newralgiczne ustalenia użytkownika. Źródło prawdy dla kodu i agentów: Postgres dam_kv_store.program-instructions (+ lokalny cache ten plik). memory.md jest tylko notatką operacyjną - przy konflikcie wygrywa ten magazyn. Po każdej nowej krytycznej decyzji: dopisz instrukcję tutaj, zapisz przez bridge (seed KV), dopiero potem zmieniaj kod.", "source_of_truth": {"related": ["naming-dictionary", "app-settings", "lifecycle-status", "change-log", "carrier-assignment-log"], "local_cache": "apps/web/data/program-instructions.json", "postgres_kv": "program-instructions", "settings_ui": "settings.html#damProgramInstructions"}}	2026-07-18T19:39:47.612471+00:00	local_bridge
lifecycle-status	{"history": [{"id": "lc_1784400909202", "ts": "2026-07-18T18:55:09.203007+00:00", "ops": [{"op": "rename", "to": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST - F", "from": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST", "kind": "variant", "new_name": "BAT - 35 g - 18.07.2026 - TEST-TEST - F", "new_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST - F", "previous_name": "BAT - 35 g - 18.07.2026 - TEST-TEST", "previous_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST"}], "path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST", "actor": "krzysztof.wieczorek@kubara.pl", "notes": [], "scope": "variant", "action": "lifecycle_status", "letter": "F", "status": "aktualne", "product_id": "test-lifecycle-nerkowcowy", "product_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]", "revision_index": ""}, {"id": "lc_1784400909368", "ts": "2026-07-18T18:55:09.368149+00:00", "ops": [{"op": "rename", "to": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST", "from": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST - F", "kind": "variant", "new_name": "BAT - 35 g - 18.07.2026 - TEST-TEST", "new_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST", "previous_name": "BAT - 35 g - 18.07.2026 - TEST-TEST - F", "previous_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST - F"}], "path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST - F", "actor": "krzysztof.wieczorek@kubara.pl", "notes": [], "scope": "variant", "action": "lifecycle_status", "letter": null, "status": "clear", "product_id": "test-lifecycle-nerkowcowy", "product_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]", "revision_index": ""}, {"id": "lc_1784403405819", "ts": "2026-07-18T19:36:45.819892+00:00", "ops": [{"op": "rename", "to": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\BABKA CYTRYNOWA — [ nerkowcowy ]\\\\KAR6X - 07.05.2026 - 6300684.01 - F", "from": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\BABKA CYTRYNOWA — [ nerkowcowy ]\\\\KAR6X - 07.05.2026 - 6300684.01", "kind": "variant", "new_name": "KAR6X - 07.05.2026 - 6300684.01 - F", "new_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\BABKA CYTRYNOWA — [ nerkowcowy ]\\\\KAR6X - 07.05.2026 - 6300684.01 - F", "previous_name": "KAR6X - 07.05.2026 - 6300684.01", "previous_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\BABKA CYTRYNOWA — [ nerkowcowy ]\\\\KAR6X - 07.05.2026 - 6300684.01"}], "path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\BABKA CYTRYNOWA — [ nerkowcowy ]\\\\KAR6X - 07.05.2026 - 6300684.01", "actor": "krzysztof.wieczorek@kubara.pl", "notes": [], "scope": "variant", "action": "lifecycle_status", "letter": "F", "status": "aktualne", "product_id": "babka-cytrynowa-nerkowcowy", "product_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\BABKA CYTRYNOWA — [ nerkowcowy ]", "revision_index": "6300684.01"}, {"id": "lc_1784404768232", "ts": "2026-07-18T19:59:28.232377+00:00", "ops": [{"op": "rename", "to": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST - D", "from": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST", "kind": "variant", "new_name": "BAT - 35 g - 18.07.2026 - TEST-TEST - D", "new_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST - D", "previous_name": "BAT - 35 g - 18.07.2026 - TEST-TEST", "previous_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST"}], "path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST", "actor": "krzysztof.wieczorek@kubara.pl", "notes": [], "scope": "variant", "action": "lifecycle_status", "letter": "D", "status": "demo", "product_id": "test-lifecycle-nerkowcowy", "product_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]", "revision_index": "TEST-TEST"}], "products": {}, "revisions": {"TEST-TEST": {"path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST - D", "letter": "D", "status": "demo", "product_id": "test-lifecycle-nerkowcowy", "updated_at": "2026-07-18T19:59:28.232389+00:00", "updated_by": "krzysztof.wieczorek@kubara.pl", "previous_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST"}, "6300684.01": {"path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\BABKA CYTRYNOWA — [ nerkowcowy ]\\\\KAR6X - 07.05.2026 - 6300684.01 - F", "letter": "F", "status": "aktualne", "product_id": "babka-cytrynowa-nerkowcowy", "updated_at": "2026-07-18T19:36:45.819907+00:00", "updated_by": "krzysztof.wieczorek@kubara.pl", "previous_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\BABKA CYTRYNOWA — [ nerkowcowy ]\\\\KAR6X - 07.05.2026 - 6300684.01"}, "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST": {"path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST", "letter": null, "status": "clear", "product_id": "test-lifecycle-nerkowcowy", "updated_at": "2026-07-18T18:55:09.368165+00:00", "updated_by": "krzysztof.wieczorek@kubara.pl", "previous_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST - F"}, "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST - F": {"path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST - F", "letter": "F", "status": "aktualne", "product_id": "test-lifecycle-nerkowcowy", "updated_at": "2026-07-18T18:55:09.203026+00:00", "updated_by": "krzysztof.wieczorek@kubara.pl", "previous_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST"}}, "updated_at": "2026-07-18T19:59:28.232460+00:00"}	2026-07-18T19:59:28.495341+00:00	local_bridge
product-status	{"products": {}, "revisions": {"TEST-TEST": {"note": "Lifecycle D", "letter": "D", "status": "demo"}, "6300684.01": {"note": "Lifecycle F", "letter": "F", "status": "aktualne"}, "6300726.00": {"note": "CZARNA PORZECZKA - podstawowy DOY", "status": "nieaktualne"}, "6300726.01": {"note": "CZARNA PORZECZKA - ZELAZO", "status": "nieaktualne"}, "6300726.02": {"note": "CZARNA PORZECZKA - MAGNEZ", "status": "nieaktualne"}, "6300727.00": {"note": "MALINA - podstawowy DOY", "status": "nieaktualne"}, "6300727.01": {"note": "MALINA - ZELAZO", "status": "nieaktualne"}, "6300727.02": {"note": "MALINA - MAGNEZ", "status": "nieaktualne"}, "6300753.00": {"note": "CZARNA PORZECZKA - MAGNEZ & ZELAZO", "status": "aktualne"}, "6300754.00": {"note": "MALINA - MAGNEZ & ZELAZO", "status": "aktualne"}, "D:/Marketing/- POLSKA/01 - PRODUKTY/- DK/02 - KULKI/MALINA — [ owocowe ]/DOY - 65 g - 24.02.2026 - 6300727.00": {"note": "Zastapione wariantem MAGNEZ & ZELAZO", "status": "nieaktualne"}, "X:/Marketing/- POLSKA/01 - PRODUKTY/- DK/01 - BATONY/BABKA CYTRYNOWA — [ nerkowcowy ]/KAR6X - 07.05.2026 - 6300684.01": {"note": "Lifecycle F", "letter": "F", "status": "aktualne"}, "D:/Marketing/- POLSKA/01 - PRODUKTY/- DK/02 - KULKI/MALINA — [ owocowe ]/DOY - MAGNEZ - 65 g - 24.02.2026 - 6300727.02": {"note": "Zastapione wariantem MAGNEZ & ZELAZO", "status": "nieaktualne"}, "D:/Marketing/- POLSKA/01 - PRODUKTY/- DK/02 - KULKI/CZARNA PORZECZKA — [ owocowe ]/DOY - 65 g - 24.02.2026 - 6300726.00": {"note": "Zastapione wariantem MAGNEZ & ZELAZO", "status": "nieaktualne"}, "D:/Marketing/- POLSKA/01 - PRODUKTY/- DK/02 - KULKI/MALINA — [ owocowe ]/DOY - ŻELAZO - 65 g - 24.02.2026 - 6300727.01": {"note": "Zastapione wariantem MAGNEZ & ZELAZO", "status": "nieaktualne"}, "X:/Marketing/- POLSKA/01 - PRODUKTY/- DK/01 - BATONY/TEST LIFECYCLE — [ nerkowcowy ]/BAT - 35 g - 18.07.2026 - TEST-TEST": {"note": "Lifecycle D", "letter": "D", "status": "demo"}, "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST": {"note": "Lifecycle clear", "letter": null, "status": "clear"}, "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\BABKA CYTRYNOWA — [ nerkowcowy ]\\\\KAR6X - 07.05.2026 - 6300684.01 - F": {"note": "Lifecycle F", "letter": "F", "status": "aktualne"}, "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST - D": {"note": "Lifecycle D", "letter": "D", "status": "demo"}, "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST - F": {"note": "Lifecycle clear", "letter": null, "status": "clear"}, "D:/Marketing/- POLSKA/01 - PRODUKTY/- DK/02 - KULKI/CZARNA PORZECZKA — [ owocowe ]/DOY - MAGNEZ - 65 g - 24.02.2026 - 6300726.02": {"note": "Zastapione wariantem MAGNEZ & ZELAZO", "status": "nieaktualne"}, "D:/Marketing/- POLSKA/01 - PRODUKTY/- DK/02 - KULKI/MALINA — [ owocowe ]/DOY - MAGNEZ & ŻELAZO - 65 g - 24.02.2026 - 6300754.00": {"note": "Aktualny nosnik MAGNEZ & ZELAZO", "status": "aktualne"}, "D:/Marketing/- POLSKA/01 - PRODUKTY/- DK/02 - KULKI/CZARNA PORZECZKA — [ owocowe ]/DOY - ŻELAZO - 65 g - 24.02.2026 - 6300726.01": {"note": "Zastapione wariantem MAGNEZ & ZELAZO", "status": "nieaktualne"}, "D:/Marketing/- POLSKA/01 - PRODUKTY/- DK/02 - KULKI/CZARNA PORZECZKA — [ owocowe ]/DOY - MAGNEZ & ŻELAZO - 65 g - 24.02.2026 - 6300753.00": {"note": "Aktualny nosnik MAGNEZ & ZELAZO", "status": "aktualne"}}, "updated_at": "2026-07-18T19:59:28.705932+00:00"}	2026-07-18T19:59:28.733138+00:00	local_bridge
app-settings	{"naming": {"source_kv": "naming-dictionary", "description_pl": "W programie zawsze pelna nazwa nosnika (DOYPACK, FOLIA, BATON). Na dysku Windows (rename folderu/pliku) zawsze skrot (DOY, FOL, BAT). Skroty istnieja tylko po to, zeby nazwy w Eksploratorze zajmowaly mniej miejsca.", "dictionary_version": 3, "carrier_display_in_ui": "label_pl", "carrier_prefix_on_disk": "short"}, "version": 2, "updated_at": "2026-07-18", "instructions": {"count": 17, "version": 4, "source_kv": "program-instructions", "critical_ids": ["data.lang_provenance_only", "meta.source_of_truth", "naming.carrier_ui_vs_disk", "ops.change_log_is_truth", "lifecycle.status_fxd", "ui.em_dash_ban", "ui.verify_screenshot", "ui.geex_only", "auth.roles_and_privilege", "storage.marketing_sensitive", "carrier.do_not_guess", "ui.tag_casing_global"], "settings_anchor": "settings.html#damProgramInstructions"}}	2026-07-18T19:39:47.276899+00:00	local_bridge
change-log	{"redo": [], "entries": [{"id": "chg_1784400747310", "ts": "2026-07-18T18:52:27.310713+00:00", "note": "Naprawa: pelny prefiks folderu -> skrot (UI nadal pelna nazwa)", "actor": "system:fix_doypack_folder_prefixes", "action": "rename_carrier", "category": "carrier", "carrier_to": "DOY", "carrier_from": "DOYPACK", "file_renames": [], "folder_rename": {"new_name": "DOY - 20.09.2024 - 6300490.00 - GB AR", "new_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOY - 20.09.2024 - 6300490.00 - GB AR", "old_name": "DOYPACK - 20.09.2024 - 6300490.00 - GB AR", "old_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOYPACK - 20.09.2024 - 6300490.00 - GB AR"}}, {"id": "chg_1784400747302", "ts": "2026-07-18T18:52:27.302345+00:00", "note": "Naprawa: pelny prefiks folderu -> skrot (UI nadal pelna nazwa)", "actor": "system:fix_doypack_folder_prefixes", "action": "rename_carrier", "category": "carrier", "carrier_to": "DOY", "carrier_from": "DOYPACK", "file_renames": [], "folder_rename": {"new_name": "DOY - 17.02.2025 - 6300624.00 - SK HU HR", "new_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOY - 17.02.2025 - 6300624.00 - SK HU HR", "old_name": "DOYPACK - 17.02.2025 - 6300624.00 - SK HU HR", "old_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOYPACK - 17.02.2025 - 6300624.00 - SK HU HR"}}, {"id": "chg_1784399410829", "ts": "2026-07-18T18:30:10.829525+00:00", "actor": "krzysztof.wieczorek@kubara.pl", "action": "rename_carrier", "category": "carrier", "carrier_to": "DOY", "product_id": "date-orange-balls-raw", "carrier_from": "", "file_renames": [{"new_name": "GC-DOY-balls_cocoa-orange_GB_СZ_SK_HU_HR_edit - 6300624.00_F.ai", "new_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOYPACK - 17.02.2025 - 6300624.00 - SK HU HR\\\\2 - PROJECT\\\\GC-DOY-balls_cocoa-orange_GB_СZ_SK_HU_HR_edit - 6300624.00_F.ai", "old_name": "GC_balls_cocoa-orange_GB_СZ_SK_HU_HR_6300624_2025_02_17_edit_F.ai", "old_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOYPACK - 17.02.2025 - 6300624.00 - SK HU HR\\\\2 - PROJECT\\\\GC_balls_cocoa-orange_GB_СZ_SK_HU_HR_6300624_2025_02_17_edit_F.ai"}, {"new_name": "GC-DOY-balls_cocoa-orange_GB_СZ - SK_HU_HR - 6300624.00_FQ.ai", "new_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOYPACK - 17.02.2025 - 6300624.00 - SK HU HR\\\\2 - PROJECT\\\\GC-DOY-balls_cocoa-orange_GB_СZ - SK_HU_HR - 6300624.00_FQ.ai", "old_name": "GC_balls_cocoa-orange_GB_СZ_SK_HU_HR_6300624_2025_02_17_FQ.ai", "old_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOYPACK - 17.02.2025 - 6300624.00 - SK HU HR\\\\2 - PROJECT\\\\GC_balls_cocoa-orange_GB_СZ_SK_HU_HR_6300624_2025_02_17_FQ.ai"}, {"new_name": "GC-DOY-balls_cocoa-orange_GB_СZ - SK_HU_HR - 6300624.00_FQ.pdf", "new_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOYPACK - 17.02.2025 - 6300624.00 - SK HU HR\\\\2 - PROJECT\\\\GC-DOY-balls_cocoa-orange_GB_СZ - SK_HU_HR - 6300624.00_FQ.pdf", "old_name": "GC_balls_cocoa-orange_GB_СZ_SK_HU_HR_6300624_2025_02_17_FQ.pdf", "old_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOYPACK - 17.02.2025 - 6300624.00 - SK HU HR\\\\2 - PROJECT\\\\GC_balls_cocoa-orange_GB_СZ_SK_HU_HR_6300624_2025_02_17_FQ.pdf"}, {"new_name": "GC-DOY-balls_cocoa-orange_GB_СZ_SK_HU_HR_FQ_podgląd - 6300624.00.pdf", "new_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOYPACK - 17.02.2025 - 6300624.00 - SK HU HR\\\\2 - PROJECT\\\\GC-DOY-balls_cocoa-orange_GB_СZ_SK_HU_HR_FQ_podgląd - 6300624.00.pdf", "old_name": "GC_balls_cocoa-orange_GB_СZ_SK_HU_HR_6300624_2025_02_17_FQ_podgląd.pdf", "old_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOYPACK - 17.02.2025 - 6300624.00 - SK HU HR\\\\2 - PROJECT\\\\GC_balls_cocoa-orange_GB_СZ_SK_HU_HR_6300624_2025_02_17_FQ_podgląd.pdf"}, {"new_name": "GC-DOY-balls_cocoa-orange_GB_СZ_SK_HU_HR_edit_PREV - 6300624.00.png", "new_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOYPACK - 17.02.2025 - 6300624.00 - SK HU HR\\\\4 - VISUALS\\\\GC-DOY-balls_cocoa-orange_GB_СZ_SK_HU_HR_edit_PREV - 6300624.00.png", "old_name": "GC_balls_cocoa-orange_GB_СZ_SK_HU_HR_6300624_2025_02_17_edit_PREV-.png", "old_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOYPACK - 17.02.2025 - 6300624.00 - SK HU HR\\\\4 - VISUALS\\\\GC_balls_cocoa-orange_GB_СZ_SK_HU_HR_6300624_2025_02_17_edit_PREV-.png"}], "product_name": "DATE ORANGE", "folder_rename": {"new_name": "DOYPACK - 17.02.2025 - 6300624.00 - SK HU HR", "new_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOYPACK - 17.02.2025 - 6300624.00 - SK HU HR", "old_name": "17.02.2025 - 6300624.00 - SK HU HR", "old_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\17.02.2025 - 6300624.00 - SK HU HR"}}, {"id": "chg_1784399460961", "ts": "2026-07-18T18:31:00.961344+00:00", "actor": "krzysztof.wieczorek@kubara.pl", "action": "rename_carrier", "category": "carrier", "carrier_to": "DOY", "product_id": "date-orange-balls-raw", "carrier_from": "DOY", "file_renames": [{"new_name": "GC-DOY-balls_cocoa-orange - GB_AR - 6300490.00_FQ.ai", "new_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOYPACK - 20.09.2024 - 6300490.00 - GB AR\\\\2 - PROJECT\\\\GC-DOY-balls_cocoa-orange - GB_AR - 6300490.00_FQ.ai", "old_name": "GC_balls_cocoa-orange_GB_AR_6300490_2024_09_26_FQ.ai", "old_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOYPACK - 20.09.2024 - 6300490.00 - GB AR\\\\2 - PROJECT\\\\GC_balls_cocoa-orange_GB_AR_6300490_2024_09_26_FQ.ai"}, {"new_name": "GC-DOY-balls_cocoa-orange - GB_AR - 6300490.00_FQ.pdf", "new_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOYPACK - 20.09.2024 - 6300490.00 - GB AR\\\\2 - PROJECT\\\\GC-DOY-balls_cocoa-orange - GB_AR - 6300490.00_FQ.pdf", "old_name": "GC_balls_cocoa-orange_GB_AR_6300490_2024_09_26_FQ.pdf", "old_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOYPACK - 20.09.2024 - 6300490.00 - GB AR\\\\2 - PROJECT\\\\GC_balls_cocoa-orange_GB_AR_6300490_2024_09_26_FQ.pdf"}, {"new_name": "GC-DOY-balls_cocoa-orange - GB_AR_FQ - 6300490.00_preview.pdf", "new_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOYPACK - 20.09.2024 - 6300490.00 - GB AR\\\\2 - PROJECT\\\\GC-DOY-balls_cocoa-orange - GB_AR_FQ - 6300490.00_preview.pdf", "old_name": "GC_balls_cocoa-orange_GB_AR_6300490_2024_09_26_FQ_preview.pdf", "old_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOYPACK - 20.09.2024 - 6300490.00 - GB AR\\\\2 - PROJECT\\\\GC_balls_cocoa-orange_GB_AR_6300490_2024_09_26_FQ_preview.pdf"}], "product_name": "DATE ORANGE", "folder_rename": {"new_name": "DOYPACK - 20.09.2024 - 6300490.00 - GB AR", "new_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\DOYPACK - 20.09.2024 - 6300490.00 - GB AR", "old_name": "20.09.2024 - 6300490.00 - GB AR", "old_path": "X:\\\\Marketing\\\\- EKSPORT\\\\01 - PRODUCTS\\\\- GC\\\\02 - BALLS\\\\DATE ORANGE — [ balls_raw ]\\\\20.09.2024 - 6300490.00 - GB AR"}}, {"id": "chg_1784400909203", "ts": "2026-07-18T18:55:09.203630+00:00", "path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST - F", "actor": "krzysztof.wieczorek@kubara.pl", "notes": [], "scope": "variant", "action": "lifecycle_status", "letter": "F", "status": "aktualne", "product_id": "test-lifecycle-nerkowcowy", "path_renames": [{"kind": "variant", "new_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST - F", "old_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST"}], "folder_rename": {"new_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST - F", "old_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST"}, "revision_index": "", "lifecycle_history_id": "lc_1784400909202"}, {"id": "chg_1784400909374", "ts": "2026-07-18T18:55:09.374015+00:00", "path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST", "actor": "krzysztof.wieczorek@kubara.pl", "notes": [], "scope": "variant", "action": "lifecycle_status", "letter": null, "status": "clear", "product_id": "test-lifecycle-nerkowcowy", "path_renames": [{"kind": "variant", "new_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST", "old_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST - F"}], "folder_rename": {"new_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST", "old_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST - F"}, "revision_index": "", "lifecycle_history_id": "lc_1784400909368"}, {"id": "chg_1784403405820", "ts": "2026-07-18T19:36:45.820583+00:00", "path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\BABKA CYTRYNOWA — [ nerkowcowy ]\\\\KAR6X - 07.05.2026 - 6300684.01 - F", "actor": "krzysztof.wieczorek@kubara.pl", "notes": [], "scope": "variant", "action": "lifecycle_status", "letter": "F", "status": "aktualne", "product_id": "babka-cytrynowa-nerkowcowy", "path_renames": [{"kind": "variant", "new_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\BABKA CYTRYNOWA — [ nerkowcowy ]\\\\KAR6X - 07.05.2026 - 6300684.01 - F", "old_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\BABKA CYTRYNOWA — [ nerkowcowy ]\\\\KAR6X - 07.05.2026 - 6300684.01"}], "folder_rename": {"new_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\BABKA CYTRYNOWA — [ nerkowcowy ]\\\\KAR6X - 07.05.2026 - 6300684.01 - F", "old_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\BABKA CYTRYNOWA — [ nerkowcowy ]\\\\KAR6X - 07.05.2026 - 6300684.01"}, "revision_index": "6300684.01", "lifecycle_history_id": "lc_1784403405819"}, {"id": "chg_1784404768232", "ts": "2026-07-18T19:59:28.232873+00:00", "path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST - D", "actor": "krzysztof.wieczorek@kubara.pl", "notes": [], "scope": "variant", "action": "lifecycle_status", "letter": "D", "status": "demo", "product_id": "test-lifecycle-nerkowcowy", "path_renames": [{"kind": "variant", "new_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST - D", "old_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST"}], "folder_rename": {"new_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST - D", "old_path": "X:\\\\Marketing\\\\- POLSKA\\\\01 - PRODUKTY\\\\- DK\\\\01 - BATONY\\\\TEST LIFECYCLE — [ nerkowcowy ]\\\\BAT - 35 g - 18.07.2026 - TEST-TEST"}, "revision_index": "TEST-TEST", "lifecycle_history_id": "lc_1784404768232"}]}	2026-07-18T19:59:28.277022+00:00	local_bridge
product-name-pl	{"names": {"FISH": "Ryba", "BALLS": "Kulki", "BURGER": "Burger", "ENERGY": "Energia", "MINCED": "Mielone", "NUGGETS": "Nuggetsy", "SZNYCEL": "Sznycel", "3PACK OAT": "3PACK owies", "DATE LIME": "Daktyle limonka", "GYROS PEA": "Gyros z grochu", "RISSOLESS": "Klopsiki", "SALTY NUT": "Słony orzech", "CHEESECAKE": "Sernik", "GI CARAMEL": "GI karmel", "BURGER BEEF": "Burger wołowy", "DATE CHERRY": "Daktyle wiśnia", "DATE ORANGE": "Daktyle pomarańcza", "GI BANOFFEE": "GI banoffee", "GINGERBREAD": "Piernik", "GYROS WHEAT": "Gyros z pszenicy", "MCT CARAMEL": "MCT karmel", "PATE TOMATO": "Pasztet pomidorowy", "MATCHA LEMON": "Matcha cytryna", "SOUSAGES BBQ": "Kiełbaski BBQ", "3PACK PROTEIN": "3PACK proteina", "DUCAT ITALIAN": "Dukat włoski", "MANGO CASHEWS": "Mango nerkowce", "BURGER BETROOT": "Burger buraczany", "BURGER CHICKEN": "Burger z kurczaka", "COCONUT ORANGE": "Kokos pomarańcza", "OATS CHOCOLATE": "Owies czekolada", "RASPBERRY TART": "Tarta malinowa", "SOUSAGES SPICY": "Kiełbaski ostre", "CASHEWS COCONUT": "Nerkowce kokos", "CRUNCHY PEANUTS": "Chrupiące orzechy", "LEMON BUNDT CAKE": "Babka cytrynowa", "BLACKCURRANT CAKE": "Czarna porzeczka", "PEANUT CREAM SALT": "Krem orzechowy sól", "HAZELNUT CHOCOLATE": "Laskowy czekolada", "GI LEMON CHEESECAKE": "GI sernik cytrynowy", "PEANUT CREAM CARAMEL": "Krem orzechowy karmel", "PEANUT CREAM VANILLA": "Krem orzechowy wanilia", "CORNFLAKES PEANUTS HONEY": "Kukurydziane orzech miód"}, "version": 1, "updated_at": "2026-07-18", "description_pl": "Polskie nazwy dla angielskich produktow (marka GC / eksport). UI: pod nazwa EN, po nowej linii, w nawiasie ze spacjami - np. MINCED + ( Mielone ). Klucz = display_name uppercase."}	2026-07-18T19:39:48.203180+00:00	local_bridge
product-people	{"by_id": {"falafel-niemiesne": ["Krzysztof"], "nuggets-niemiesne": ["Krzysztof"], "shot-funkcjonalne": ["Krzysztof"], "shot-funkcjonalny": ["Krzysztof"], "sznycel-niemiesne": ["Krzysztof"], "nuggets-plant-based": ["Krzysztof"], "sznycel-plant-based": ["Krzysztof"], "cynamonka-nerkowcowy": ["Krzysztof"], "energia-funkcjonalny": ["Sylwia"], "proteina-banoffee-ig": ["Sylwia", "Krzysztof"], "nuggets-xxl-niemiesne": ["Krzysztof"], "burger-burak-niemiesne": ["Krzysztof"], "odpornosc-funkcjonalny": ["Sylwia"], "prebiotyk-funkcjonalny": ["Sylwia"], "dk-doy-datesy-yuzu-100-g": ["Sylwia", "Krzysztof"], "mielone-wolowe-niemiesne": ["Sylwia"], "proteina-karmel-z-mct-ig": ["Sylwia", "Krzysztof"], "mix-tuba-30-szt-xmas-mixy": ["Krzysztof", "Szymon"], "owies-czekolada-sniadanie": ["Krzysztof"], "burger-buraczany-niemiesne": ["Krzysztof"], "ciasto-sliwkowe-nerkowcowy": ["Krzysztof"], "dk-doy-datesy-karmel-100-g": ["Sylwia", "Krzysztof"], "sousages-spicy-plant-based": ["Sylwia"], "oats-chocolate-balls-crispy": ["Krzysztof"], "owies-czekolada-sniadaniowe": ["Krzysztof"], "dk-doy-datesy-marakuja-100-g": ["Sylwia", "Krzysztof"], "mielone-wolowe-xxl-niemiesne": ["Sylwia"], "mix-kalendarz-adwentowy-mixy": ["Sylwia", "Szymon"], "proteina-lemon-cheesecake-ig": ["Sylwia", "Krzysztof"], "roladki-szpinakowe-niemiesne": ["Sylwia"], "kielbaska-wegierska-niemiesne": ["Sylwia"], "krem-orzechowy-sol-proteinowy": ["Sylwia", "Krzysztof"], "proteina-karmel-krem-orzechowy": ["Sylwia", "Krzysztof"], "krem-orzechowy-karmel-proteinowy": ["Sylwia", "Krzysztof"], "proteina-banoffee-krem-orzechowy": ["Sylwia", "Krzysztof"], "proteina-karmel-mct-funkcjonalny": ["Sylwia", "Krzysztof"], "krem-orzechowy-wanilia-proteinowy": ["Sylwia", "Krzysztof"], "dk-doy-datesy-lemoncheesecake-100-g": ["Sylwia", "Krzysztof"], "proteina-lemon-cheesecake-krem-orzechowy": ["Sylwia", "Krzysztof"]}, "notes": ["Display Rossmann 6300787: Krzysztof (siatka) — indeks w by_index; produkt moze nie istnieć w file-index.", "Karton export GC traysealer: Sylwia (Asana) — brak jednoznacznego product_id w indeksie.", "Chrupkulki / nowe shoty z Asany 10.07: Krzysztof — mapowane na shot-* gdy istnieja.", "Nie renderowac imion jako glosnych badge na kartach; tylko search_blob + tag_groups.autor + by_tag."], "people": {"Sylwia": {"full": "Sylwia Zarychta", "aliases": ["sylwia", "zarychta"]}, "Szymon": {"full": "Szymon Ryngwelski", "aliases": ["szymon", "ryngwelski"]}, "Krzysztof": {"full": "Krzysztof Wieczorek", "aliases": ["krzysztof", "wieczorek"]}}, "version": 1, "by_index": {"6300381": ["Sylwia", "Szymon"], "6300406": ["Sylwia"], "6300578": ["Krzysztof"], "6300602": ["Sylwia"], "6300603": ["Sylwia"], "6300610": ["Krzysztof"], "6300651": ["Sylwia", "Szymon"], "6300653": ["Sylwia"], "6300757": ["Krzysztof"], "6300782": ["Krzysztof"], "6300783": ["Krzysztof"], "6300784": ["Krzysztof"], "6300785": ["Krzysztof"], "6300787": ["Krzysztof"]}, "source_pl": "Status Sylwii (kartony/mielone/kalendarz/datesy) + spis Szymona + dziennik KW 29.06–10.07. Cel: wyszukiwanie po imieniu, bez widocznych badge TAG na kartach.", "updated_at": "2026-07-18", "by_id_prefix": {"dk-doy-datesy": ["Sylwia", "Krzysztof"]}}	2026-07-18T19:39:48.408745+00:00	local_bridge
\.


--
-- Data for Name: device_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.device_sessions (id, user_id, device_id, machine_id, session_id, windows_user, hostname, token_hash, created_at, last_seen_at, revoked) FROM stdin;
1	1	dam-dev-a6a2acce751029d4e04eb1e410740948	dam-mid-a6a2acce751029d4e04eb1e410740948	dam-sid-exvvR1f1rZyk97awIRTfKOCNeN3_7Jvr	xpret	inyfinn	60cbd70cac6edaa9b189a69155b854f9b1141cc2ba85ff2b18815bfafc23c5c7	2026-07-18T08:23:51.685049+00:00	2026-07-18T19:59:52.792751+00:00	f
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, name, role, password_hash, auth_provider, created_at, updated_at) FROM stdin;
1	krzysztof.wieczorek@kubara.pl	Krzysztof Wieczorek	admin	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:52:34.147789+00:00	2026-07-18T00:53:15.512123+00:00
2	agata.karon@kubara.pl	Agata Karon	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
3	andzelika.borowicz@kubara.pl	Andzelika Borowicz	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
4	anna.polanska@kubara.pl	Anna Polanska	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
5	beata.scibik@kubara.pl	Beata Scibik	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
6	dagmara.bartnik@kubara.pl	Dagmara Bartnik	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
7	ewa.prazmowska@kubara.pl	Ewa Prazmowska	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
8	justyna.zroslak@kubara.pl	Justyna Zroslak	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
9	karolina.kubara@kubara.pl	Karolina Kubara	power_user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
10	maciej.labus@kubara.pl	Maciej Labus	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
11	magazyn.detal@kubara.pl	Magazyn Detal	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
12	malgorzata.oleksiak@kubara.pl	Malgorzata Oleksiak	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
13	marek.milek@kubara.pl	Marek Milek	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
14	marek.paluszewski@kubara.pl	Marek Paluszewski	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
15	marta.zasepa@kubara.pl	Marta Zasepa	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
16	ryszard.domagala@kubara.pl	Ryszard Domagala	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
17	sylwia.zarychta@kubara.pl	Sylwia Zarychta	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
18	szymon.ryngwelski@kubara.pl	Szymon Ryngwelski	user	$2b$12$TZfIPYOrNA1bHpkCDXREyed0UfM20n5.YdP160XWKd4s/Q68.mjVS	local	2026-07-18T00:53:15.512123+00:00	2026-07-18T00:53:15.512123+00:00
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 25, true);


--
-- Name: device_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.device_sessions_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 18, true);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: dam_kv_store dam_kv_store_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dam_kv_store
    ADD CONSTRAINT dam_kv_store_pkey PRIMARY KEY (store_key);


--
-- Name: device_sessions device_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_sessions
    ADD CONSTRAINT device_sessions_pkey PRIMARY KEY (id);


--
-- Name: device_sessions device_sessions_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_sessions
    ADD CONSTRAINT device_sessions_token_hash_key UNIQUE (token_hash);


--
-- Name: device_sessions device_sessions_user_id_device_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_sessions
    ADD CONSTRAINT device_sessions_user_id_device_id_key UNIQUE (user_id, device_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: audit_log_action_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_action_idx ON public.audit_log USING btree (action);


--
-- Name: audit_log_ts_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_ts_idx ON public.audit_log USING btree (ts DESC);


--
-- Name: audit_log_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_user_idx ON public.audit_log USING btree (username);


--
-- Name: users_email_lower_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_lower_idx ON public.users USING btree (lower(email));


--
-- Name: device_sessions device_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_sessions
    ADD CONSTRAINT device_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict RnQCYPX6gcXeLjX5rQbChl0uoPZ2xdgdKPZkvbWlJN1a1djwBWyDDm7gFqYfzyg

